# ARQUIVO - QV1 (pacote completo do projeto QV / Quanto Vale)

Este pacote é o ARQUIVO VIRAL original (arquivo-viral-atlas-1-NUCLEO-pasta-unica.zip + REFS) SEM NENHUMA ALTERAÇÃO, mais tudo o que foi criado e aprendido depois, na pasta QV1/. Nada do que você já tinha foi mexido: só foi ACRESCENTADO.

## Como usar em qualquer conversa nova
1. Anexe o ARQUIVO-QV1.zip (e, se quiser as referências, os zips ARQUIVO-QV1-REFS-A/B/C) na conversa.
2. Cole o texto de QV1/PROMPT-PARA-COLAR.txt.
3. A IA deve: descompactar, ler QV1/LEIA-PRIMEIRO.md e QV1/docs/*.md, instalar o setup (docs/03), restaurar o motor (codigo/) e começar a produzir a meta do dia sozinha.

## O que existe aqui dentro
- arquivo-viral-atlas-1-NUCLEO-pasta-unica.zip e REFS/ : originais, intocados (REFS = os 6 vídeos de referência do usuário; 4, 5, 6 = estilo antigo; 7, 8, 9 = estilo alvo).
- QV1/docs/ : manual detalhado (regras, análise quadro a quadro, motor vertical, motor horizontal, voz, sons, entrega no Drive, autonomia, pesquisa de temas, lições, skills e repositórios).
- QV1/codigo/ : motor vertical (vertical_neo) e horizontal (horizontal_hk) prontos, com fontes e logo QV.
- QV1/analise_refs/ : folhas de contato e cortes medidos das referências + ferramenta de análise (codigo/ferramentas/analisar_ref.py).
- QV1/exemplos_roteiros/ : roteiros reais já entregues (modelo para copiar o formato).
- QV1/skill/ : texto atual da skill arquivo-viral-qv.
- QV1/tarefas_agendadas/ : prompt completo da tarefa diária independente.

## Meta diária (sem o usuário mandar nada)
10 reels VERTICAIS (1080x1920, 60 fps, >=63 s) + 2 explicativos HORIZONTAIS (1920x1080, 60 fps, >=481 s). Verticais primeiro, depois horizontais. Terminou um MP4 entregue, começa o próximo na hora. Meia-noite (America/Sao_Paulo) zera e começa o lote do dia seguinte.

## Limites que a IA deve dizer com honestidade
Voz e movimento dos vídeos nunca foram ouvidos nem assistidos pela IA (só ffprobe, quadros de teste e folhas de contato). Alguns repositórios exigem API paga e NÃO foram usados. Anexo no chat: no máximo 30 MB por arquivo (ver docs/07).
