#!/usr/bin/env python3
"""Analise quadro a quadro de videos de referencia.
Uso: python3 analisar_ref.py video1.mp4 [video2.mp4 ...]
Gera: cuts.json (instantes dos cortes) e sNOME.jpg (folha de contato, 30 cortes ou 1 quadro a cada 2 s).
Corte = diferenca media entre quadros (90x160 cinza) > 18."""
import cv2, sys, json, os, numpy as np
out={}
for p in sys.argv[1:]:
    cap=cv2.VideoCapture(p); fps=cap.get(cv2.CAP_PROP_FPS) or 30
    prev=None; diffs=[]; frames=[]
    while True:
        ok,f=cap.read()
        if not ok: break
        g=cv2.cvtColor(cv2.resize(f,(90,160)),cv2.COLOR_BGR2GRAY).astype(np.float32)
        diffs.append(0 if prev is None else float(np.abs(g-prev).mean())); prev=g
        frames.append(cv2.resize(f,(180,320)))
    d=np.array(diffs); dur=len(d)/fps
    cuts=[]; last=-99
    for i,v in enumerate(d):
        if v>18 and i-last>4: cuts.append(round(i/fps,2)); last=i
    still=float((d<0.3).mean()*100)
    print(f"{os.path.basename(p)}: {dur:.1f}s cortes={len(cuts)} ({len(cuts)/dur:.2f}/s) mov_medio={d.mean():.2f} p90={np.percentile(d,90):.2f} parados={still:.1f}%")
    out[os.path.basename(p)]=cuts
    idx=[min(len(frames)-1,int((c+0.15)*fps)) for c in cuts[:30]] if len(cuts)>=8 else list(range(0,len(frames),int(2*fps)))[:30]
    cols=10; rows=(len(idx)+cols-1)//cols
    sheet=np.zeros((rows*320,cols*180,3),np.uint8)
    for k,i in enumerate(idx):
        r,c=divmod(k,cols); sheet[r*320:(r+1)*320,c*180:(c+1)*180]=frames[i]
        cv2.putText(sheet,f"{i/fps:.1f}s",(c*180+4,r*320+16),cv2.FONT_HERSHEY_SIMPLEX,0.5,(0,255,0),1)
    cv2.imwrite("s"+os.path.splitext(os.path.basename(p))[0]+".jpg",sheet)
json.dump(out,open("cuts.json","w"))
