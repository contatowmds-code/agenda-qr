---
name: "arquivo-viral-qv"
description: "Produz em loop autônomo vídeos do perfil QV (Quanto Vale): 10 reels verticais (63 s+) e 2 vídeos explicativos horizontais (8:01+) por dia, entrega o MP4 no Drive."
---

# /arquivo-viral-QV

Usa a skill `arquivo-viral` (motor, QA, regras de voz Santa, 60 fps, fundo vivo) SEMPRE com a identidade QV. Não perguntar perfil: é QV.

## Identidade QV
Fundo #011839, destaque #01FBB4, logo `marca/perfis/QV-logo-confirmada.png` sem recolorir. @ do perfil ainda desconhecido: não inventar.

## Loop autônomo
Terminou um vídeo (MP4 entregue no Drive) -> iniciar o próximo sem esperar comando. Meta do usuário (13/11/2026, substitui qualquer meta anterior): por dia, 10 REELS VERTICAIS (1080x1920, mínimo 63 s) + 2 VÍDEOS EXPLICATIVOS HORIZONTAIS (1920x1080, mínimo 8:01) ensinando algo com IA. Ordem: primeiro os 10 verticais, depois os 2 horizontais. Controlar a contagem do dia (fuso America/Sao_Paulo) e anunciar em 1 linha o progresso (ex.: reels 3/10, horizontais 0/2). Se a sessão/ferramenta impedir continuar, dizer claramente quantos faltam; nunca declarar meta cumprida sem os MP4 reais.

## Tipos de vídeo
REGRA DO USUÁRIO (13/11/2026, 18:07): só existem dois formatos. NUNCA vídeo de 8 min na vertical.
- REEL VERTICAL (10/dia): 1080x1920, mínimo 63 s, 60 fps nativos, gancho forte <=5 s, CTA FIXO (texto exato, falado e na legenda): "Quer criar vídeos como esse? Comente ARQUIVO que vou te enviar a mesma skill que eu utilizo para criar vídeos assim, mas você precisa estar me seguindo para a mensagem chegar." Estilo MUITO dinâmico como as referências do usuário (e o motor Arquivo): troca de cena a cada ~1-2 s, legenda palavra a palavra (karaoke), fundo vivo que reage à cena, câmera/zoom/parallax, transições com wipe de destaque, ícones e UIs animados. Proibido simples, genérico ou estático.
- EXPLICATIVO HORIZONTAL (2/dia): 1920x1080, mínimo 8 min 1 s (481 s), mesmo estilo dinâmico, passo a passo real e verificado ensinando a fazer algo com IA. Conferir duração com ffprobe; se curto, acrescentar conteúdo útil (nunca silêncio, repetição ou congelamento).
Mesma paleta QV nos dois.

## Tema
Pesquisar sozinho (GitHub, lançamentos, notícias da semana), checar fato em fonte primária, escolher UM tema, nunca repetir tema já feito (já feitos: last30days, mattpocock/skills). Informar tema e motivo em 2 linhas. Sem pedir aprovação.

## Regras visuais (13/11/2026, obrigatórias em TODO vídeo)
- O fundo AJUDA A EXPLICAR a cena: cada cena tem fundo próprio ligado ao assunto (ex.: memória = células que se acendem e são guardadas; compressão = blocos grandes virando um pequeno; fluxo = dados correndo entre elementos). Nunca fundo genérico, simples, estático ou decorativo.
- Pouco texto na tela: a legenda já fala. Cada cena tem no máximo 1-3 palavras de rótulo; nada de blocos de texto, listas escritas ou frases longas na imagem.
- Explicar com IMAGEM: exemplos concretos, personagens/ícones, objetos animados, diagramas que se constroem, antes/depois, metáforas visuais fáceis de entender.
- ZERO repetição: não repetir o mesmo tipo de cena, layout, fundo ou animação em cenas seguidas nem entre vídeos; variar tipo de cena, ângulo, movimento e transição.

## Padrão de edição das referências (análise quadro a quadro, 13/11/2026). Vale para TODO vídeo daqui em diante
Família A (neon 3D hipercortado): UMA ideia por cena, cena nova a cada 0,7-2 s (nunca 5 s). Título curto no topo (2-4 palavras) que se monta palavra por palavra, com a palavra-chave em caixa de destaque (texto escuro na caixa da cor de destaque); objeto 3D brilhoso grande no centro (ícone, moeda, estrela, calendário, notebook com teclas, presente, interruptor, ponte, tesoura), sombra no chão. Fundos que alternam entre escuro com piso em grade, cor de destaque chapada, bege claro e palco vermelho para contraste. Transição por túnel de linhas de velocidade/flash. Números contam subindo com explosão de partículas. Cursor/mão clicando, X ou check animados.
Família B (demo de tela): interfaces falsas realistas (janelas, tabelas, cartões, barras de progresso, ondas de áudio, linha do tempo) que se preenchem sozinhas, com zoom/câmera entre painéis e legenda pequena palavra a palavra com a palavra-chave destacada.
Família C (mundo desenhado): cenário com profundidade e câmera em movimento, bonecos simples, objetos e números que surgem, mudança de cenário e de cor a cada ideia.
Autocrítica obrigatória: antes de entregar, comparar com as referências; se a cena for plana, lenta (mais de 2,5 s), com fundo parado ou texto demais, refazer. Os reels 1 e 2 do QV ficaram abaixo desse padrão (cenas de 5 s, 2D plano, sem 3D, sem alternar fundos, sem túnel).

## Direção de câmera e plano de cena (13/11/2026, obrigatório)
- Antes de renderizar, escrever o PLANO DE CENA: por trecho da fala, qual animação entra, qual câmera (lateral, topo, baixo, aproximar, afastar, revelar) e qual fundo. Cada animação só aparece no instante em que é mencionada; não encher a tela de elementos.
- A câmera se move a cada 1 a 2 s, sempre variando (lateral, de cima, de baixo, aproximação, revelação, órbita). Nunca repetir o mesmo movimento ou fundo em cenas seguidas; usar mais de 8 fundos diferentes por vídeo.
- Foco no centro: desfoque nas laterais (vinheta com blur) e o assunto sempre no centro da tela.
- Ferramentas: MapLibre GL (flyTo/easeTo/pitch/bearing) no Chrome headless com Natural Earth (npm world-atlas) para cenas de lugar, país, mapa e escala; Terrain RGB quando houver tiles acessíveis, senão relevo sintético; Turf.js para medir áreas, distâncias e comparar tamanhos; gráficos de velocidade (medidores, linhas de aceleração, barras que correm) para dar ritmo. MapLibre renderiza ~3 s por quadro a 1080x1920: renderizar o trecho de mapa em 540x960 e escalar, e só nas cenas que precisam de mapa.
- Mapa em segmentos próprios; o restante usa o motor 2D/3D procedural. Sempre tudo sincronizado com a fala.

## Câmera com propósito (regra de 13/11/2026 20:06)
Mover a câmera NÃO é efeito: cada movimento precisa ajudar a explicar a fala naquele instante, senão o vídeo fica ruim de assistir. No plano de cena, cada mudança de câmera leva uma coluna "por quê":
- De cima (top-down): comparar tamanhos, posições, ranking, visão geral.
- Lateral/baixa (low angle): mostrar altura, tamanho, quanto uma barra ou objeto é maior que outro.
- Aproximar (push-in): detalhe, o número ou o país citado agora.
- Afastar: contexto, "somando tudo", mostrar o conjunto.
- Órbita: dar noção de volume/profundidade do que está sendo explicado.
- Voo (flyTo) entre dois lugares: só quando a fala liga os dois (comparação, rota, ultrapassagem).
- Revelar: a informação aparece quando a câmera chega nela, na palavra que a cita.
Proibido mover a câmera só para variar: a cada 1-2 s algo muda, mas a mudança segue o conteúdo (se o assunto não muda, mudar o ângulo para mostrar outro aspecto do mesmo dado).

## Lote diário, pesquisa e ferramentas (regra de 13/11/2026 20:18)
- Meta: 10 verticais (63 s+) + 2 horizontais (8:01+) por dia, tudo autônomo, sem o usuário intervir. Ao virar a meia-noite (America/Sao_Paulo) o contador zera e começa o lote do dia seguinte sozinho (tarefa agendada às 00:05 se a sessão acabar).
- Pesquisa de tema SEMPRE com as skills last30days (GitHub), Agent Reach e Viralyzer (o que viraliza e o gancho), cruzando os resultados; checar o fato em fonte primária e nunca repetir tema.
- Backgrounds NUNCA repetidos: cada vídeo usa cenários/mapas/estilos diferentes dos anteriores e, dentro do vídeo, não repetir fundo em cenas seguidas; registrar os fundos usados para o próximo não repetir.

## Melhorar a cada vídeo
Paleta QV fixa. Todo o resto evolui: fundo e movimento, metáforas por cena, transições, ritmo, estilo de legenda, SFX/música, gancho. Antes de criar, listar o que o anterior usou e escolher o que mudar; ao fim, registrar 3-5 linhas do que aprendeu e melhorará. Fundo sempre vivo (reage à cena).

## Entrega no Drive
Subir SOMENTE o MP4, SEM criar subpasta (regra de 13/11/2026 19:56): o arquivo vai direto na pasta QV https://drive.google.com/drive/folders/1PjYAexyF3NNCMHuBsi1KJj7kapAyqu3E, renomeado "TÍTULO + 3 hashtags.mp4". Sem .txt e sem capa separada: a capa é o primeiro frame, e antes de entregar é obrigatório conferir esse frame 0 (título grande, elemento principal, cor forte, bem chamativo); se não for, refazer. Texto de postagem só no chat. Anexar o MP4 também no chat. Confirmar tamanho e parentId depois.

## Como subir
Apps Script web app (URL e editor na skill arquivo-viral), segredo lido só dentro do JS da página (rodar `configurar`), blocos de 3.145.728 bytes com file_upload + ação `bloco`. Aprendido: a ação `iniciar` ignora o parâmetro `pai` e grava na pasta raiz AV; depois mover o arquivo com update_file(parentId) para a subpasta QV. MÉTODO SEM PC LIGADO (preferido): git push do MP4 para a branch qv-upload (pasta videos/) do repo contatowmds-code/agenda-qr; disparar o workflow manual "Subir MP4 para o Drive" (id 417569639, inputs arquivo e nome; gh api -X POST repos/contatowmds-code/agenda-qr/actions/workflows/417569639/dispatches -f ref=main -f inputs[arquivo]=... -f inputs[nome]=...); o arquivo cai na raiz do script e deve ser movido com update_file(parentId) direto para a pasta QV e renomeado (title) para "TÍTULO + 3 hashtags.mp4", sem subpasta; confirmar tamanho e parentId. Pipelines (vertical e horizontal) ficam na branch qv-pipeline. O Chrome do usuário só é alternativa.

## Áudio e desfoque (regra de 13/11/2026 19:56)
- Sem música e sem ambiente. Só efeitos sonoros nas transições e em cada elemento que entra, sai, sobe ou desce, no frame exato do movimento: whoosh na troca de câmera, pop/impacto na entrada, tick no contador, swoosh na saída. Um som por evento.
- Desfoque lateral (tilt-shift) mais ESCURO nas laterais. NENHUM elemento importante (barras, rótulos, objetos, texto) pode ficar sobre a área desfocada: manter tudo na zona central nítida (x entre ~190 e ~890); se algo sairia dela, reenquadrar a câmera ou o elemento.

## Técnicas dos repositórios (obrigatório aplicar)
Baixar e ler: Vincentwei1021/video-shotcraft, haidrrrry/claude-remotion-skill, bangtutorial/bang-motion, Vincentwei1021/anything2explainer, hi-nikola/hand-drawn-explainer-video-nikola, lintsinghua/paint-mv-skills, CK42BB/vox-explainer-skill, Alisa0808/vox-director (git clone --depth 1 em /home/claude/ref). Resumo e regras em pipeline/CRAFT_QV.md (branch qv-pipeline do repo contatowmds-code/agenda-qr): easing nunca linear, entradas com 2-3 propriedades, tudo escalonado, saídas mais rápidas, 5 camadas por cena com grão/vinheta/cor, ritmo HIT-segura-constrói, uma pancada por cena, fundos de colagem de papel (Vox), roteiro em arco (abertura fria, virada de contexto, explicação crescente, complicação, reenquadramento). Pipelines que exigem API paga (Atlas Cloud, Volcengine, fal.ai) não são usados: dizer isso.

## Execução contínua e independente
Meta diária sem depender de mensagem do usuário: 10 verticais + 2 horizontais; terminou um MP4 entregue, começa o próximo na mesma execução (sem send_later, sem pausa); à meia-noite (America/Sao_Paulo) começa o lote novo. Tarefa agendada de hora em hora é só vigia e usa a trava registro/placar-qv-arquivo.json (branch qv-upload) e fire_trigger para encadear. Runbook: pipeline/RUNBOOK_DIARIO_QV.md.

## Ritmo exato das referências (análise quadro a quadro dos 6 vídeos enviados em 14/11/2026)
Medido com diferença de quadros: os vídeos 7, 8 e 9 (alvo) têm 1,25 a 1,64 cortes por segundo e <1,5% de quadros parados; os 4, 5 e 6 (estilo antigo, telas escuras com interface) têm ~0,1 a 0,2 corte/s e são o que NÃO repetir. Padrão do alvo: a MESMA ideia aparece em 2 a 3 cenas rápidas, cada uma mais rica que a anterior (objeto pequeno -> objeto grande com cartão -> explosão/confete; ex.: estrela, depois estrela com número, depois estrela explodindo). Título no topo se monta palavra por palavra (palavra pequena primeiro, depois a palavra-chave em caixa de destaque). Fundos alternam: preto com túnel de linhas de velocidade, cor chapada com piso em grade, estúdio claro, palco vermelho com fumaça. Objetos 3D brilhosos com sombra/reflexo, mão clicando, X/check, contador subindo, calendário, interruptor, presente, relógio. Regra prática: nenhuma cena passa de ~1,6 s; cada fala vira 2 sub-cenas (fundo novo, objeto reentra maior, flash de luz, SFX pop+whoosh).

## Motor vertical (pasta pipeline/vertical_neo, branch qv-pipeline) — o que foi aprendido
- Pipeline: roteiro.py (cenas H(o=objeto,o2=segundo,tt="TÍTULO *chave* | linha2",bg=0..12,n=contador,cam=[...])) -> tts.py (Kokoro pm_santa, velocidade 1.2-1.35) -> timeline.py (PAUSE/GAP entre falas; usar 0.05/0.06 quando houver 40+ cenas) -> audio.py (só SFX) -> render.py K N em 2 processos -> concat+mux -> ffprobe.
- hero.py: 13 fundos (0-9 antigos; 10 kraft, 11 jornal, 12 bloco de cor com colagem de papel rasgado, meio-tom e fita), tiltshift escuro nas laterais, camwarp (push, pull, left, right, up, down, low; nunca inversão), finish() com vinheta+grão+contraste, sub-cena na 2ª metade de cada fala (bg2 opcional). Capa = quadro 0: forçar título E objeto visíveis no quadro 0 (senão a capa sai vazia). Objetos disponíveis: bag bolt book bubble bulb calendar cart chart check chip clock coin cursor doc download folder gear gift graph heart laptop lock magnet magnifier phone phonebot plug robot rocket shield star toggle trophy tv tvad tvclean xmark.
- Duração: ~3 palavras/s a 1.2-1.35; 200-210 palavras e 45-50 cenas dão 65-75 s. Conferir o total na timeline ANTES de renderizar (63 a 75 s).
- TTS: respelling por REPL em tts.py (RTX=érre tê xis, GPU=gê pê iú, GitHub=Guitrâb, Linux=Línucs, BIOS=Báios, kernel=quérnel, GPL=gê pê éle, npm=êne pê ême, Rust=Râst, MIT, Apache, Anthropic etc.) + 4º argumento de b() para pronúncia só daquela fala; números por extenso na fala.
- Temas já feitos (não repetir): OfficeCLI, last30days, mattpocock/skills, criação de skills, hooks, claude-mem, janela de contexto, maiores economias, PIB da América do Sul, CleanYourTV, unslop, Mika, LearnHarness, Mister Download Manager, craft-anything (horizontal), gpu-unlock (vertical 14/11). Candidatos: janestreet/agent_skills, l0ng-ai/openidea, novos do GitHub trending (gh api -X GET search/repositories -f q='created:>AAAA-MM-DD stars:>3000' -f sort=stars).

## Motor horizontal (pasta pipeline/horizontal_hk)
1920x1080, VIS: big, title, code, term, tree, cards, cmp, steps, flow, exit, cta1, cta2. Roteiro de tutorial = capítulos (hook, c1..cN, resumo, CTA em dois beats cta2+cta1). ~1.550 palavras = 505 s; ~1.800 palavras = 588 s. Render em 8 partes (seq 0 7 | xargs -P2). O render a 1920x1080 sai ~130-145 MB: reencodar com -b:v 1200k -maxrate 1800k -bufsize 3600k para ~85 MB antes do envio. Modelo de roteiro pronto: roteiro_unslop.py. Próximo passo de qualidade: levar para o horizontal o ritmo do alvo (sub-cenas, fundos alternando, câmera com propósito, tilt-shift) e inserir fundos de colagem.

## Armadilhas operacionais (aprendidas)
- Processos em segundo plano morrem quando a execução para: esperar render em loops `for i in $(seq 1 57); do pgrep -f render.py >/dev/null || break; sleep 10; done` (máx ~9 min por chamada) e religar só as partes que faltam; se o ambiente reiniciar, conferir part*.mp4 e logs.
- git: dois agentes mexem na mesma branch qv-upload. Sempre `git pull --rebase origin qv-upload` antes de empurrar, nunca apagar MP4 de outra sessão (resolver conflito mantendo o arquivo dela), usar `git add -f videos/X.mp4` (a pasta pode estar ignorada), conferir que o push chegou (`git ls-remote origin qv-upload`) e que o workflow achou o arquivo.
- Workflow 417569639 leva ~2-4 min para 85 MB; esperar com loop até `completed success`. O arquivo cai na raiz 1tPiMtGGzyESOgy_wN1_T_EnDeNt-yx_I; mover com update_file para a pasta QV e renomear.
- Lembretes via send_later podem chegar horas depois; não usá-los para encadear vídeos. Encadear na mesma execução e, se ela acabar, a tarefa agendada de hora em hora religa.
- A conta pode atingir limite de uso e a tarefa agendada falhar (USAGE_LIMIT_REACHED): registrar em falhas e dizer ao usuário.
- Skills do usuário só mudam por propose_skills; o usuário precisa salvar o cartão.

## Ferramentas de pesquisa e criativas (o que existe e o que não)
last30days (clonar mvanhorn/last30days-skill; precisa de plano), Agent Reach (clonar Panniantong/Agent-Reach; `agent-reach github search ...`), viralyzer (só existe PedroHenriqueIII/Viralyzer, um SaaS de Instagram, não instalável como skill: usar análise própria de gancho/retenção). Repositórios de vídeo em /home/claude/ref: video-shotcraft (Remotion, 124 cartas de plano, regras de ritmo/qualidade/som), claude-remotion-skill (regras de movimento), bang-motion (HTML+GSAP, anti-PPT), anything2explainer (explicativo com barra de capítulos e pesquisa com fonte), hand-drawn-explainer (traço escrevendo), paint-mv-skills (aquarela), vox-explainer-skill e vox-director (colagem de papel; exigem API paga Atlas Cloud, não usar a API, usar só o estilo e o roteiro em arco). Verificação honesta: nada foi assistido nem ouvido por mim, só quadros de teste, ffprobe e folhas de contato.

## Contrato
Só declarar "pronto" com MP4 real exportado e QA técnico (qa_video.py). Voz e movimento não foram ouvidos/vistos por mim: dizer isso.