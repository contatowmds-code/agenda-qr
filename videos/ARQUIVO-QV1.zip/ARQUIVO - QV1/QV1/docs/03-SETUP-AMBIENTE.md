# Setup do ambiente de produção (sessão nova, Linux, 2 CPUs)
pip install kokoro-onnx soundfile scipy opencv-python-headless numpy pillow phonemizer --break-system-packages
apt-get install -y ffmpeg espeak-ng (se faltar)
Modelos da voz (GitHub releases, sem login), ~340 MB, NÃO estão no pacote:
  curl -L -o k.onnx https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/kokoro-v1.0.onnx
  curl -L -o v.bin  https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/voices-v1.0.bin
Voz: pm_santa (reels), velocidade 1.2-1.35.
Pastas: copie QV1/codigo/vertical_neo para /home/claude/neo e QV1/codigo/horizontal_hk para /home/claude/hk; coloque k.onnx e v.bin dentro de cada uma.
Rede do sandbox: só registros de pacotes (pip/npm), github.com via git clone e raw.githubusercontent.com. curl/wget a outros sites costuma ser bloqueado. WebFetch de github bloqueado: usar git clone. `gh api` funciona para busca de repositórios, mas dá 403 em repo privado/não adicionado.
Natural Earth (mapas): curl -s -o ne50.json https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_50m_admin_0_countries.geojson (usado só nos reels de mapa).
Pesquisa:
  git clone --depth 1 https://github.com/mvanhorn/last30days-skill (precisa de --plan)
  git clone --depth 1 https://github.com/Panniantong/Agent-Reach && pip install ./Agent-Reach --break-system-packages; agent-reach github search ...  (pip por zip de URL dá 403)
Repositórios de técnica (docs/11): git clone --depth 1 em /home/claude/ref.
Node 22 e Chrome existem no sandbox, mas NÃO usamos Remotion (render 60 fps com 2 CPUs é lento): o motor é Python.
