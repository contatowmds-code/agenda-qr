# Sons (audio.py) - sem música, só efeitos sincronizados
Mix final = voz*1.0 + SFX*0.8. Música de fundo foi REMOVIDA por regra do usuário (o código antigo de música ainda existe no fim do audio.py mas não entra na mixagem).
SFX gerados por síntese (sem arquivos externos), 48 kHz:
- pop (0,14 s): seno que cai de 1400 Hz para 500 Hz, decaimento rápido = elemento entra. volume 0.55-0.8.
- blip (0,12 s): seno 1200 Hz curtíssimo = segundo objeto entra.
- tick (0,06 s): seno 1900 Hz + ruído agudo = contador subindo (5 ticks por contador).
- whoosh (0,6 s): ruído filtrado 400-3500 Hz com envelope em seno² = troca de câmera/transição/sub-cena.
- glitch, squash, type, error: disponíveis (entrada de código, esmagar, digitação, erro).
- impact, thud, ding: existem, mas são IGNORADOS (ficavam altos demais).
Regra: um som por evento, no quadro exato em que o elemento começa a se mover: E.hit(t, 'pop', volume) registra em SFX; audio.py coloca cada som em sfx[int(t*SR)]. No motor horizontal, cada visual (big, title, cards...) registra seus hits na entrada e na saída. Elementos que saem/descem usam whoosh curto; subindo = pop agudo.
Se o usuário pedir SFX reais: o repositório video-shotcraft traz references/sound-design.md e sfx-sourcing.md (busca de sons livres no Freesound com sfx-source.py). Não baixar sem conferir licença.
