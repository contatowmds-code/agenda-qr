# Lições aprendidas desde o início (resumo detalhado)
## Produto
- Reels 1-3 ficaram no padrão antigo (cenas de 5 s, 2D plano). Reels 4-5 (mapas 3D de PIB) têm câmera com rotação alta no 4 e 5 (corrigido depois: bearing ±22°). Reels 6-10 usam o motor "hero" (CleanYourTV, unslop, Mika, LearnHarness, Mister Download Manager). 14/11: gpu-unlock com 1 cena nova a cada ~1,6 s e sub-cenas.
- Temas já feitos: OfficeCLI, last30days, mattpocock/skills, criação de skills, hooks, claude-mem, janela de contexto, maiores economias do mundo (FMI), PIB América do Sul, CleanYourTV, unslop (vertical e horizontal), Mika, LearnHarness, Mister Download Manager, craft-anything (horizontal), gpu-unlock. Candidatos: janestreet/agent_skills, l0ng-ai/openidea, novos do trending.
## Técnicas
- Capa vazia: no quadro 0 o objeto ainda não tinha entrado -> forçar visível.
- Cores invertidas (RGB x BGR) no mapa; rótulos/barras ilegíveis -> limitar rótulos a x 400-680 e desenhar barras DEPOIS do tilt-shift.
- Câmera de cabeça para baixo: limitar bearing a ±22°.
- Elementos não podem ir para a área desfocada.
- Tempo: verificar duração na timeline antes de renderizar; 52 cenas deram 90 s -> cortar cenas e baixar PAUSE/GAP.
- Render: 2 CPUs; vertical 2 partes, horizontal 8 partes (`seq 0 7 | xargs -P2`); processos morrem com a sessão; se o ambiente reiniciar, apagar partes incompletas e religar só as faltantes.
- Tamanho: horizontal 1080p60 = 130-145 MB; reencode para ~80 MB (Drive) e ~27 MB (chat).
## Operacional
- git: branch qv-upload compartilhada com outra sessão; pull --rebase; git add -f; conferir push; não apagar arquivos alheios.
- send_later pode atrasar horas; usar fire_trigger/encadeamento na mesma execução.
- propose_skills: o usuário precisa salvar o cartão; se o SKILL.md mudou, reenviar com edits ancorados em títulos estáveis (## Contrato).
- WebFetch de github bloqueado; usar git clone. gh api 403 em repo não adicionado.
- A IA nunca assistiu/ouviu os vídeos: dizer sempre.
