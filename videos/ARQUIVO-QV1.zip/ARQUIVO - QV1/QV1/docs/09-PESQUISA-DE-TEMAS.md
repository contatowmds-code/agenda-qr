# Como escolher o tema
1. GitHub em alta: `gh api -X GET search/repositories -f q='created:>AAAA-MM-DD stars:>3000' -f sort=stars -f per_page=15 -q '.items[]|"\(.full_name) \(.stargazers_count) \(.description)"'` (trocar a data pelos últimos 30 dias).
2. Agent Reach: `agent-reach github search "..."` (Reddit/X/YouTube só se o canal funcionar; dizer o que falhou).
3. last30days: clonar mvanhorn/last30days-skill, ler SKILL.md, rodar com --plan.
4. Viralyzer: não existe como skill instalável (só PedroHenriqueIII/Viralyzer, um SaaS de Instagram). Dizer isso e usar análise própria de gancho/retenção (primeiros 5 s concretos, número, contraste, promessa).
5. Clonar o repositório escolhido e LER o README (fato em fonte primária). Anotar licença, requisitos, passo a passo real, limitações. Conferir contra o README cada número falado e dizer "segundo o projeto" quando for benchmark do próprio autor.
6. Nunca repetir tema (lista em docs/10). Sem religião. Sem promessa de ganho financeiro; aviso de risco.
7. Horizontal = tutorial "ensinando a fazer algo com IA": instalar, requisitos, passo a passo, comandos reais, cuidados, licença. 13+ capítulos (hook, c1..cN, resumo, CTA) e 1.600-1.800 palavras = 8:25-9:45 a velocidade 1.2.
