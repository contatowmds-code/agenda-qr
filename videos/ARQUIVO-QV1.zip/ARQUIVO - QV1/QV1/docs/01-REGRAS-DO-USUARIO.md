# Regras do usuário (MATIELLO) em ordem de aparição - valem sobre qualquer outra coisa

## Identidade e tema
- Perfil QV = Quanto Vale. Fundo #011839, destaque #01FBB4, logo QV-logo.png SEM recolorir. @ do perfil: não inventar.
- NUNCA tema de religião (regra fixa do projeto QV).
- Tema sempre novo, nunca repetido; não falar só de geografia/economia: usar tecnologia, IA, ferramentas do GitHub, finanças, etc.
- Pesquisar o tema com as skills last30days (GitHub), Agent Reach e "viralyzer"; conferir o fato em fonte primária.

## Metas
- Por dia: 10 reels verticais (>=63 s, 1080x1920, 60 fps) + 2 vídeos horizontais explicativos (>=8:01 = 481 s, 1920x1080, 60 fps, ensinando algo com IA passo a passo). NUNCA vídeo de 8 min na vertical.
- Verticais primeiro, horizontais depois. Meia-noite (America/Sao_Paulo) zera o contador e começa o lote seguinte.
- Totalmente autônomo e independente: sem depender do PC do usuário, sem esperar o usuário mandar mensagem, sem intervalos entre vídeos (terminou um, já começa o outro), independente de outras gerações em outros projetos.

## CTA final (falado E escrito nas últimas cenas)
"Quer criar vídeos como esse? Comente ARQUIVO que vou te enviar a mesma skill que eu utilizo para criar vídeos assim, mas você precisa estar me seguindo para a mensagem chegar."

## Entrega
- Só o MP4. SEM subpasta. Direto na pasta QV do Drive (id 1PjYAexyF3NNCMHuBsi1KJj7kapAyqu3E), renomeado "TÍTULO #hashtag1 #hashtag2 #hashtag3.mp4". Sem .txt e sem capa separada.
- A capa é o PRIMEIRO FRAME: sempre conferir (extrair e olhar) que está muito chamativa.
- Texto de postagem só no chat. Anexar o MP4 também no chat.
- Anexo no chat: o limite é 30 MB por arquivo (aviso "Alguns arquivos eram grandes demais para anexar. O tamanho máximo é 30 MB"). Mandar cópia leve (<=28 MB) no chat e manter a versão melhor no Drive.

## Áudio
- SEM música, SEM ambiente. Apenas efeitos sonoros: nas transições e em CADA elemento que entra, sai, sobe ou desce, no instante exato do movimento. Um som por evento.

## Visual
- A câmera muda a cada 1-2 s, mas cada movimento precisa ajudar a explicar a fala naquele instante (não é só mexer). A câmera NUNCA pode parecer de cabeça para baixo (limitar rotação a ±22°).
- Desfoque lateral (tilt-shift) mais ESCURO, foco no centro; nenhum elemento importante pode ficar na área desfocada.
- Cada animação só aparece quando é mencionada na fala. Pouco texto na tela (1-3 palavras de rótulo).
- Fundos nunca repetidos (nem em cenas vizinhas, nem entre vídeos). O fundo ajuda a explicar a cena.
- Escrever o PLANO DE CENA antes de renderizar (fala | objeto | câmera | por quê | fundo).
- "A cada segundo deve ter um quadro e uma cena nova": não é repetir animação nem só colocar transição; cada cena é uma imagem NOVA (objeto, fundo, ângulo, título diferentes). Referência medida: 1,25 a 1,64 cortes/s.

## Skills e repositórios que o usuário mandou usar
video-shotcraft, claude-remotion-skill, bang-motion, anything2explainer, hand-drawn-explainer, paint-mv-skills, vox-explainer (ver docs/11).

## Estilo de resposta do usuário
Quer execução imediata ("EXEC", "COMECE"), sem perguntas; reclama de intervalos entre vídeos e de qualquer coisa que dependa dele.
