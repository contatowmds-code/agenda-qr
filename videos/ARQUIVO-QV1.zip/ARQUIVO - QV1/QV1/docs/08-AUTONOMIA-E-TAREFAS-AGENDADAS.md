# Autonomia: como garantir os 10+2 vídeos todo dia, sem intervalos
- Dentro da execução: depois de entregar um vídeo, comece o próximo imediatamente na MESMA execução. NÃO use send_later para encadear: um lembrete chegou 1h39 depois porque só é entregue quando a execução está ociosa.
- Tarefa agendada (create_trigger/update_trigger) "QV Arquivo Viral: cadeia contínua": roda de hora em hora (cron CRON_TZ=America/Sao_Paulo 17 * * * *) como VIGIA; usa trava em registro/placar-qv-arquivo.json (branch qv-upload) com {"dia","verticais":[],"horizontais":[],"falhas":[],"lock":{"inicio","batida"}}. Se lock.batida tem menos de 150 min, outra execução está produzindo: encerrar. Senão assume o lock, produz UM vídeo, atualiza o placar, solta o lock e dispara a próxima com fire_trigger (mesma tarefa). Ao virar o dia (Brasília) zera as listas. Prompt completo em tarefas_agendadas/.
- Existem outras tarefas de outros projetos (QR, AV, 'QV stick'): ignorar; cada projeto tem seu placar e seu lock próprios.
- Limite de uso da conta pode derrubar a tarefa (USAGE_LIMIT_REACHED): registrar em falhas e avisar o usuário.
- Contagem: confira a pasta QV do Drive (arquivos criados hoje) para não contar vídeo que não existe nem duplicar.
- Placar do dia 13/11: verticais 10/10, horizontais 2/2 (unslop e craft-anything, este com roteiro 587,9 s). Dia 14/11 começou com o reel gpu-unlock.
