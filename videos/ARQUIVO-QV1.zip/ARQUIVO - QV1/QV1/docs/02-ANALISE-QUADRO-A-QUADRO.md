# Como analisar um vídeo de referência quadro a quadro (método usado)

Objetivo: tirar do vídeo de referência medidas (cortes por segundo, movimento, quadros parados) e uma folha de contato visual para copiar o PADRÃO (não os quadros, marcas ou textos).

## Passo 1 - Medir (ferramenta pronta: codigo/ferramentas/analisar_ref.py)
`python3 analisar_ref.py REFS/7.mp4 REFS/8.mp4 ...`
Para cada vídeo: lê todos os quadros em 90x160 cinza, calcula a diferença média entre quadros consecutivos; um corte = diferença > 18; agrupa cortes separados por mais de 4 quadros; imprime duração, cortes/s, movimento médio, p90 e % de quadros parados (<0.3). Salva cuts.json (instantes dos cortes).
Resultados de 14/11/2026 (720x1280, 30 fps):
- 4.mp4 (49 s): 0,14 corte/s, 25% quadros parados  -> estilo ANTIGO (telas escuras com interface). Não repetir.
- 5.mp4 (67 s): 0,07 corte/s, 28% parados -> antigo.
- 6.mp4 (29 s): 0,21 corte/s -> antigo.
- 7.mp4 (59 s): 90 cortes = 1,54/s, 0,7% parados -> ALVO.
- 8.mp4 (51 s): 84 cortes = 1,64/s, 0,1% parados -> ALVO.
- 9.mp4 (50 s): 62 cortes = 1,25/s, 1,3% parados -> ALVO.

## Passo 2 - Folha de contato
Para 7, 8, 9: um quadro logo após cada corte (t + 0,15 s), 30 cortes em grade 10 colunas, 180x320 cada, com o tempo escrito. Para 4, 5, 6: um quadro a cada 2 s. Abrir as imagens (analise_refs/s4..s9.jpg) e descrever cena por cena: objeto, título, fundo, câmera, transição.

## Passo 3 - O que foi observado nos vídeos ALVO (7, 8, 9)
- Cena nova a cada 0,7-2 s; nenhuma cena fica parada.
- A MESMA ideia aparece em 2-3 cenas seguidas, cada uma mais rica (estrela pequena -> estrela com cartão e número -> estrela explodindo em confete).
- Título curto no topo (2-4 palavras), montado palavra por palavra, borrão de entrada; palavra-chave dentro de caixa na cor de destaque com texto escuro; primeira palavra pequena branca.
- Objeto 3D brilhoso, grande, centralizado, com sombra/reflexo no chão (notebook, moeda, estrela, calendário, presente, interruptor, ponte, tesoura, relógio, celular com perfil, balão de conversa, avião de papel, moeda R$0, ícone Instagram, lâmpada, boneco-robô de capelo).
- Fundos que ALTERNAM: preto com túnel de linhas de velocidade (verde) = transição/entrada de tema; cor chapada verde-limão com piso em grade; estúdio branco/bege com raios; palco vermelho com fumaça e spots; aro neon circular.
- Contador sobe (ex.: 64 MIL) com explosão de partículas; cursor/mão branca clicando; X vermelho, check verde, sinal de proibido; selo "SKILL 1 DE 11" quando o tema é lista.
- Interfaces falsas realistas (perfil Instagram, cartões de post, linha do tempo de edição) aparecem dentro da cena quando o assunto pede.
Nossa tradução (paleta QV navy + menta): docs/04.

## Passo 4 - Regras derivadas
1. Nenhuma cena >1,6 s. 2. Cada fala vira 2 sub-cenas (fundo novo, objeto reentra maior, flash de luz, pop+whoosh). 3. Fundo nunca igual ao da cena vizinha. 4. Palavra-chave sempre destacada em caixa. 5. Capa = quadro 0 com título e objeto já visíveis.

## Passo 5 - Verificação própria
Depois de renderizar: extrair quadros (tf.py) em tempos espalhados + o 0, abrir a imagem, conferir capa, texto cortado, elemento na área desfocada, fundo repetido, cena parada. Contar cortes por segundo do vídeo final com o mesmo script (meta >=1,2/s no vertical).
Para analisar uma NOVA referência: cole o MP4 em REFS/, rode analisar_ref.py, abra os jpg, escreva as observações no mesmo formato e acrescente em docs.
