# Skills e repositórios usados/estudados
Clonar: `mkdir -p /home/claude/ref && cd /home/claude/ref && for r in Vincentwei1021/video-shotcraft haidrrrry/claude-remotion-skill bangtutorial/bang-motion Vincentwei1021/anything2explainer hi-nikola/hand-drawn-explainer-video-nikola lintsinghua/paint-mv-skills CK42BB/vox-explainer-skill Alisa0808/vox-director; do git clone -q --depth 1 https://github.com/$r; done`
- video-shotcraft (SKILL.md, references/aesthetic-rules.md R/Q/S/C/P, sound-design.md, sfx-sourcing.md, 124 cartas de plano em references/shots): ritmo (informação pousa >=1 s, aceleração, 0,5 s de pausa), qualidade/câmera, som, texto, processo. Usa Remotion; usamos só as regras.
- claude-remotion-skill: 10 regras de movimento (easing nunca linear, entrada com 2-3 propriedades, escalonar, saída mais rápida, 5 camadas com cor/grão/vinheta, respirar, HIT-segura-constrói-HIT).
- bang-motion: anti-PPT (uma pancada por cena, <=5 palavras, objeto sobe ao centro, sem 3 blocos de texto, sem ponto final).
- anything2explainer: explicativo com barra de capítulos, HUD, pesquisa com fonte, QC.
- hand-drawn-explainer-video-nikola e paint-mv-skills: traço desenhado na hora, aquarela, função do tempo; uso futuro para esquemas e fundos.
- vox-explainer-skill e vox-director: colagem de papel rasgado (borda branca, meio-tom, fita, cor chapada) e roteiro em arco: abertura fria, virada de contexto, explicação crescente, complicação, reenquadramento. Dependem de API paga (Atlas Cloud) -> NÃO usadas; só o estilo (fundos 10-12) e o arco.
Também citados pelo usuário e emulados conceitualmente: MapLibre GL, Natural Earth, Terrain RGB, Turf.js (não executados de fato; o motor de mapas é próprio em Python).
APIs pagas/chaves NÃO usadas: Atlas Cloud, Volcengine, fal.ai, Seedream, Omni Flash.
