# Motor vertical (codigo/vertical_neo) - reel 1080x1920, 60 fps, 63-75 s

## Fluxo
roteiro.py -> `python3 tts.py 1.3` (voz Kokoro por cena, gera tts.pkl) -> `python3 timeline.py` (voz.wav, tl.json; mostra "total X s") -> `python3 audio.py` (mix.wav = voz + SFX*0.8, sem música) -> `python3 tf.py t1 t2 ...` (gera tf.jpg com quadros de teste; abra e confira) -> render em 2 partes -> concat+mux -> ffprobe.
Render: `rm -f part*.mp4; (setsid nohup sh -c 'seq 0 1 | xargs -P2 -I{} python3 render.py {} 2' > render.log 2>&1 &)` e depois ESPERAR em loop: `for i in $(seq 1 57); do pgrep -f render.py >/dev/null || break; sleep 10; done` (cada chamada de shell passa de ~9-10 min vira background; processos em background morrem quando a execução para, então religar só as partes que faltam). Vertical ~0.25-0.5 s por quadro por processo: um reel de 68 s (4.100 quadros) leva ~15-20 min.
Concat: `printf "file part0.mp4\nfile part1.mp4\n" > l.txt; ffmpeg -f concat -i l.txt -i mix.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -shortest out.mp4`.

## Roteiro (roteiro.py)
`b(id, "fala com *destaque*", H(o='objeto', tt="TÍTULO *chave* | linha 2", bg=0..12, cam=['push'], o2='segundo objeto', x2=770, y2=1050, n=87, pre='+', suf='%', s=1.15, s2=0.6, bg2=N), "fala com pronúncia corrigida (opcional)")`
- cam: push, pull, left, right, up, down, low (nunca rotação invertida; limite de rotação 22° no motor de mapas).
- Fundos 0-9 originais (0 azul com raios e piso, 1 menta, 2 bege, 3 vermelho, 4 azul-escuro, 5 verde-água, 6 amarelo, 7 cinza escuro com chuva de linhas, 8 azul com ondas, 9 menta claro com quadrados); 10 kraft, 11 jornal, 12 bloco de cor: colagem de papel rasgado + meio-tom + fita (técnica Vox). Escolher bg diferente do da cena anterior (assert no gerador).
- Objetos (objs.py): bag bolt book bubble bulb calendar cart chart check chip clock coin cursor doc download folder gear gift graph heart laptop lock magnet magnifier phone phonebot plug robot rocket shield star toggle trophy tv tvad tvclean xmark.
- Cena = uma fala curta (3-6 palavras, ~1,3-1,6 s). 45-50 cenas e 200-210 palavras = 65-75 s a velocidade 1.35 com PAUSE=0.05 e GAP=0.06 em timeline.py. Conferir "total" na timeline ANTES de renderizar (63 a 75 s).
- Última cena(s): CTA exato (cena 'COMENTE ARQUIVO' + 'ME SEGUINDO'), falado e escrito.

## O que o motor faz (hero.py)
- bg() desenha o fundo; tiltshift() = desfoque lateral escurecido (centro nítido até x≈300 de 540); camwarp() = câmera (zoom/pan com easing) por cena conforme cam; objeto 3D falso (card3d) com reflexo/sombra; título palavra por palavra com caixa na palavra-chave; contador n; faíscas na entrada; finish() = vinheta + grão leve + contraste.
- Sub-cena: se a fala dura >1,15 s, na segunda metade troca o fundo (bg2 ou (bg+5)%13), o objeto reentra 14% maior, flash de raios e SFX pop+whoosh. Resultado: cena nova a cada ~0,8 s.
- Capa: no quadro 0 o título e o objeto são forçados visíveis (senão sai vazio). Sempre extrair o quadro 0 e olhar.
- SFX por cena: pop na entrada, blip quando o 2º objeto entra, 5 ticks no contador, whoosh em cada troca de câmera.
- Mapas 3D (geo.py/geo_data.py/geo_cams.py): Natural Earth 50m, câmera Mercator virtual (centro, zoom, pitch, bearing limitado a ±22°), barras 3D, anéis, arcos, medidores; usado nos reels de PIB. Só quando o tema pede mapa.

## Plano de cena (obrigatório, no próprio roteiro.py como comentário)
fala | objeto | câmera | por quê | fundo. Exemplos de por quê: down = o arquivo desce; up = número sobe; push = olhar com cuidado; low = impacto/tamanho; pull = contexto; left/right = revelar o que vem ao lado.

## Autocrítica antes de entregar
tf.py em 8 tempos espalhados: capa chamativa? texto cortado? elemento sobre a área desfocada (fora de x 190-890)? fundo igual ao vizinho? cena >1,6 s? Medir cortes/s do MP4 final.
